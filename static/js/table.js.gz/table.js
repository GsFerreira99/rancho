tab = $(document).ready( function () {
    table = $('#tabela').DataTable(
        {
            "language": {
                'url': '//cdn.datatables.net/plug-ins/1.11.5/i18n/pt-BR.json'
            },
            scrollX : true
        }
    );
} );



